// content.js - Refactored Version
console.log('content.js loaded');

// -------------------------------------------------
// Constants (Common settings such as selectors)
// -------------------------------------------------
const SELECTORS = {
  replyBox: 'div.Am.aO9.Al.editable.LW-avf',
  originalContent: 'div.adn.ads > div.gs > div:nth-child(3) > div:nth-child(3) > div',
  aiButtonContainer: 'tr.btC',
  subject: 'h2.hP',
  sender: 'span.gD',
  receiveTime: 'span.g3',
  emailContainer: 'div.Bk'
};

// -------------------------------------------------
// Global Variables
// -------------------------------------------------
let thisContentTabId = null;
let originalContentHTML = null;
let originalContentPastHTML = null;
let isListenerAdded = false;
let thisReplyBox = null;
let clickedEmail = null;

// -------------------------------------------------
// Utility Functions
// -------------------------------------------------

// HTML filtering function
// Removes all attributes from the input HTML string and inserts line breaks appropriately for specific tags (br, div, p, pre, hr)
const filterHTML = inputHTML => {
  const parser = new DOMParser();
  const doc = parser.parseFromString(inputHTML, 'text/html');
  const allElements = doc.body.getElementsByTagName('*');
  // Remove all attributes from every element
  for (let element of allElements) {
    while (element.attributes.length > 0) {
      element.removeAttribute(element.attributes[0].name);
    }
  }
  let result = [];
  const walker = document.createTreeWalker(
    doc.body,
    NodeFilter.SHOW_TEXT | NodeFilter.SHOW_ELEMENT,
    {
      acceptNode: node => {
        if (node.nodeType === Node.ELEMENT_NODE) {
          const tag = node.tagName.toLowerCase();
          if (['br', 'div', 'p', 'pre', 'hr'].includes(tag)) {
            return NodeFilter.FILTER_ACCEPT;
          }
        } else if (node.nodeType === Node.TEXT_NODE && node.textContent.trim() !== '') {
          return NodeFilter.FILTER_ACCEPT;
        }
        return NodeFilter.FILTER_SKIP;
      }
    }
  );
  while (walker.nextNode()) {
    if (walker.currentNode.nodeType === Node.ELEMENT_NODE) {
      const tag = walker.currentNode.tagName.toLowerCase();
      if (tag === 'br' || tag === 'hr') {
        result.push(`<${tag}>`);
      } else {
        // For div, p, pre tags, insert a line break before the element if not already present
        if (result[result.length - 1] !== '<br>') {
          result.push('<br>');
        }
      }
    } else if (walker.currentNode.nodeType === Node.TEXT_NODE) {
      result.push(walker.currentNode.textContent);
    }
  }
  if (result[0] === '<br>') result.shift();
  result.push('<br>');
  return result.join('');
};

// Removes any child elements within the specified selector that have white text color
const removeWhiteText = selector => {
  const elems = document.querySelectorAll(selector + ' *');
  elems.forEach(el => {
    if (window.getComputedStyle(el).color === 'rgb(255, 255, 255)') {
      el.remove();
    }
  });
};

// Placeholder: Re-fetch the original email content from the DOM
// Implement any necessary logic here. This example always returns success.
async function findOriginalContent() {
  return { error: false };
}

// -------------------------------------------------
// Create AI Button and Handle Click Events
// -------------------------------------------------

// Generates and returns the AI button
function createAIButton() {
  const tdElement = document.createElement('td');
  tdElement.className = 'td-aiButton';

  const buttonDiv = document.createElement('div');
  buttonDiv.className = 'T-I J-J5-Ji aoO v T-I-atl L3';
  buttonDiv.setAttribute('role', 'button');
  buttonDiv.setAttribute('tabindex', '1');
  buttonDiv.setAttribute('aria-label', 'Reply with AI');
  buttonDiv.style.userSelect = 'none';

  const buttonText = document.createElement('span');
  buttonText.className = 'buttonText-aiButton';
  buttonText.textContent = 'Reply with AI';

  buttonDiv.appendChild(buttonText);
  tdElement.appendChild(buttonDiv);

  buttonDiv.addEventListener('click', handleAIButtonClick);
  return tdElement;
}

// Click event handler: Extracts email content and sends it to the background process
function handleAIButtonClick() {
  // Request to store the tab ID
  try {
    chrome.runtime.sendMessage({ action: 'storeContentTabId' }, (response) => {
      thisContentTabId = response.contentTabId;
    });
  } catch (e) {
    alert("Please reload the page and try again.");
    return;
  }

  try {
    // Retrieve the nearest email container to the clicked button
    clickedEmail = this.closest(SELECTORS.emailContainer);
    if (!clickedEmail) throw new Error("Failed to find email container");

    // Get the elements containing the email body
    const originalContentElements = clickedEmail.querySelectorAll(SELECTORS.originalContent);
    thisReplyBox = clickedEmail.querySelector(SELECTORS.replyBox);

    const subjectElement = document.querySelector(SELECTORS.subject);
    const senderElement = clickedEmail.querySelector(SELECTORS.sender);
    const receiveTimeElement = clickedEmail.querySelector(SELECTORS.receiveTime);

    // If multiple elements exist, choose the one that does not have the 'yj6qo' class
    let contentIndex = 0;
    for (let i = 0; i < originalContentElements.length; i++) {
      if (!originalContentElements[i].classList.contains('yj6qo')) {
        contentIndex = i;
      }
    }

    // Remove unnecessary white text elements
    removeWhiteText();

    // Create a clone of the target content element
    const originalContentElement = originalContentElements[contentIndex];
    const cloneDiv = originalContentElement.cloneNode(true);

    // Extract and remove elements representing past email exchanges (e.g., div.h5 or div.im)
    let pastElements = cloneDiv.querySelectorAll('div.h5');
    if (pastElements.length === 0) {
      pastElements = cloneDiv.querySelectorAll('div.im');
    }
    pastElements.forEach(el => el.remove());

    originalContentHTML = filterHTML(cloneDiv.innerHTML).replace(/\s|&nbsp;/g, ' ');
    const originalContentText = cloneDiv.innerText;
    originalContentPastHTML = filterHTML(Array.from(pastElements).map(el => el.outerHTML).join('')).replace(/\s|&nbsp;/g, ' ');

    // Send a message to the background process to open the editor with the extracted email content
    chrome.runtime.sendMessage({
      action: 'openEditor',
      email_information: {
        html: originalContentHTML,
        text: originalContentText,
        title: subjectElement ? subjectElement.textContent : '',
        sender: senderElement ? senderElement.textContent : '',
        receive_time: receiveTimeElement ? receiveTimeElement.textContent : '',
        current_time: new Date().toLocaleString(),
        past_html: originalContentPastHTML
      },
    });
  } catch (e) {
    console.error(e);
    alert("An error occurred.");
  }
}

// -------------------------------------------------
// Automatically Add AI Button Using MutationObserver
// -------------------------------------------------
function addAIButtonObserver() {
  const observer = new MutationObserver(() => {
    const buttonContainers = document.querySelectorAll(SELECTORS.aiButtonContainer);
    buttonContainers.forEach(container => {
      if (container && !container.querySelector('.td-aiButton')) {
        const aiButton = createAIButton();
        container.appendChild(aiButton);
      }
    });
  });
  observer.observe(document.body, { childList: true, subtree: true });
}

// -------------------------------------------------
// Register Chrome Runtime Message Listener
// -------------------------------------------------
function addMessageListener() {
  if (!isListenerAdded) {
    chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
      if (request.action === 'reflectReply') {
        findOriginalContent().then(result => {
          if (result.error) {
            sendResponse({ status: 'false' });
          } else if (request.contentTabId === thisContentTabId) {
            thisReplyBox = clickedEmail.querySelector(SELECTORS.replyBox);
            if (thisReplyBox) {
              thisReplyBox.innerHTML = request.replyContent.replace(/\n/g, '<br>');
              sendResponse({ status: 'true' });
            } else {
              sendResponse({ status: 'false' });
            }
          } else {
            sendResponse({ status: 'differentTab' });
          }
        });
      } else if (request.action === 'serverError') {
        alert("An error occurred on the server.");
      }
      return true;
    });
    isListenerAdded = true;
  }
}

// -------------------------------------------------
// Initialization
// -------------------------------------------------
window.addEventListener('load', () => {
  addAIButtonObserver();
  addMessageListener();
});
